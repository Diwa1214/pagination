import { set } from "mongoose";
import React from "react";
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableFooter from '@material-ui/core/TableFooter';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import { Button } from "@material-ui/core";

const App=()=>{

const [state,setState] = React.useState({
    name:"",
    title:"",
    descripition:""
})

 const table = useSelector(state => state.getReducer)
 const {loading,data} = table


   return (
       <div style={{display:"flex",flexDirection:"row"}}>
           <input  onChange={(text)=>{setState({
               ...state,
               name:text
           })}}/>
           <inputon Change={(text)=>{setState({
               ...state,
               title:text
           })}} />
           <input onChange={(text)=>{setState({
               ...state,
               descripition:text
           })}}/>
           <Button onChange={()=>{
               AddAction(state.name,state.title,state.descripition)
           }}/>
           {data ? <Table >
					<TableHead>
						<TableRow>
			
						</TableRow>
					</TableHead>
					<TableBody>
						
							<TableRow key={i}>
								{data.map((col, i) => (
									<TableCell align="left" key={i} className={classes.tableBody}>
										
										{data.name}
                                        {data.title}
                                        {data.descripition}
									</TableCell>
								))}
							</TableRow>
					
						{emptyRows > 0 && (
							<TableRow style={{ height: 48 * emptyRows }}>
								<TableCell colSpan={6} />
							</TableRow>
						)}
					</TableBody>
					<TableFooter>
						<TableRow>
							<TablePagination
								rowsPerPageOptions={[ 5, 10, 25, 50 ]}
								// colSpan={12}
								count={props.data.length}
								rowsPerPage={rowsPerPage}
								page={page}
								SelectProps={{
									inputProps: { 'aria-label': 'rows per page' },
									native: true
								}}
		
							/>
						</TableRow>
					</TableFooter>
				</Table> :null
}

       </div>
   )
}

export default App