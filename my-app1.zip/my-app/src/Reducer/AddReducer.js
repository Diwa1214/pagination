
const inital ={
    loading:false,
    data:[]
}
export const AddReducer = (inital,action) =>{
   switch(action.type){
      case "GET_PRODUCT_REQUEST":
          return {
              loading:true
          }
      case "GET_PRODUCT_SUCCESS":
          return {
              loading:false,
              data:action.payload
          }
   }
}

export const AddPostReducer = (inital,action) =>{
    switch(action.type){
       case "ADD_PRODUCT_REQUEST":
           return {
               loading:true
           }
       case "ADD_PRODUCT_SUCCESS":
           return {
               loading:false,
               data:action.payload
           }
    }
 }