import axios from "axios"


const GetAction =()=>async(dispatch)=>{
   dispatch({
       type:"GET_PRODUCT_REQUEST"
   })
   try{
       const {data} = await axios.get("http://localhost:9001/postData")
       dispatch({
           type:"GET_PRODUCT_SUCCESS",
           payload:data
       })
   }
   catch(error){
     console.log(error);
   }
}

const AddAction =(name,title,descripition)=>async(dispatch)=>{
    dispatch({
        type:"ADD_PRODUCT_REQUEST"
    })
    try{
        const {data} = await axios.post("http://localhost:9001/getData",{name,title,descripition})
        dispatch({
            type:"ADD_PRODUCT_SUCCESS",
            payload:data
        })
    }
    catch(error){
      console.log(error);
    }
 }

