
import mongoose from "mongoose"


const ProductSchema = new mongoose.Schema(
    {
        name:{
            type:String,
        },
        title:{
            type:String,
            
        },
        description:{
            type:String
        },
       
    },{
        timestamps:true
    }
    )

    export const Product = mongoose.model("product",ProductSchema)

