import express from "express"
import {MongoClient  } from "mongodb"
import mongoose from "mongoose"
import { Product } from "./module/product"

const app = express()
app.use(express.json())
const port = 9000



app.get("/",(req,res)=>{
   res.send("Hai")
})


app.post("/postData",async(req,res)=>{
   try{
     const product = await Product.create({
        name:req.body.name,
        title:req.body.title,
        description:req.body.description
     })
     if(product){
        res.send(product)
     }
   }
   catch(error){
   
   }
})

app.get("/getData",async(req,res)=>{
   try{
      const data = await Product.find({})
      if(data){
         res.send(data)
      }
   }
   catch(error){
    console.log(error);
   }
})



app.use((err,req,res,next)=>{
  console.log(err);
   res.status(500).send({
     msg:err.messageg
   })
})

mongoose.connect("mongodb+srv://user:user@cluster0.43znc.mongodb.net/kit",{useNewUrlParser: true, useUnifiedTopology: true }).then(()=>{
  app.listen(port,()=>{
    console.log(`Server is start${port} and Connected DB`)
})
})



